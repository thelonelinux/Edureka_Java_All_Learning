package com.springcloudgatewayjwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringcloudgatewayjwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringcloudgatewayjwtApplication.class, args);
	}

}
